// about.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      userinfo:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.login({
      success: function (res) {
       
        wx.getUserInfo({
          success: function (res) {
            console.log(res)
           that.setData({
             "userinfo":res.userInfo
           })
          }
        })


      }
    });


    wx.connectSocket({
      url: 'xss://clownm.herokuapp.com'
    })
    wx.onSocketOpen(function (res) {
      console.log('WebSocket连接已打开！')
    })

  }


  
})