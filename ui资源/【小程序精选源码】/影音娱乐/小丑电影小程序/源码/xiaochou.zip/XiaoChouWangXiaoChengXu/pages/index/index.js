//index.js
//获取应用实例
var app = getApp()
var order = ['red', 'yellow', 'blue', 'green', 'red']
Page({
  data: {
    imgUrls: [
      'http://ohe9dkyrl.bkt.clouddn.com/image/Pursuit/Pursuit.jpg',
      'http://ohe9dkyrl.bkt.clouddn.com/image/La-leggenda/La-leggenda.jpg',
      'http://ohe9dkyrl.bkt.clouddn.com/image/Titanic/Titanic.jpg',
      'http://ohe9dkyrl.bkt.clouddn.com/image/%E9%80%9F%E5%BA%A6%E4%B8%8E%E6%BF%80%E6%83%858/%E9%80%9F%E5%BA%A6%E4%B8%8E%E6%BF%80%E6%83%858.jpg'
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
  
    movie:[],
    paihang:[]
  },
  onLoad:function(){
    var that=this;
    wx.request({
      url: 'https://clownm.herokuapp.com/', 
      method:"post",
      data: {
      },
      success: function (res) {
        console.log(res.data)
        that.setData({
          "movie":res.data.movie
        })
      }
    });

    wx.request({
      url: 'https://clownm.herokuapp.com/res/paihang.json',
      method: "get",
      data: {
      },
      success: function (res) {
        console.log(res.data)
        that.setData({
          "paihang":res.data
        })
      }
    })


  },
  
  
})