Page({
  data: {
    markers: [{
      iconPath: "../../public/image/logo.png",
      id: 0,
      latitude: 23.099994,
      longitude: 113.324520,
      width: 50,
      height: 50
    }],
    polyline: [{
      points: [{
        longitude: 113.3245211,
        latitude: 23.10229
      }, {
        longitude: 113.324520,
        latitude: 23.21229
      }],
      color: "#FF0000DD",
      width: 2,
      dottedLine: true
    }],
    controls: [{
      id: 1,
      iconPath: '../../public/image/logo.png',
      position: {
        left: 0,
        top: 300 - 50,
        width: 50,
        height: 50
      },
      clickable: true
    }],
    moviearr:[],
    type:0,
    color: ["rgb(255, 255, 255)", "rgb(199, 179, 229)","rgb(199, 179, 229)"],

  },
  onLoad:function(e){
    var that=this;
    wx.showLoading({
      title: '查找中',
    })
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        
        that.setData({
          latitude : res.latitude,
          longitude :res.longitude
        })

      }
    })

    wx.request({
      url: 'https://api-m.mtime.cn/Showtime/LocationMovies.api?locationId=290',
      method: "get",
      header: {
        'content-type': 'application/json'
      },
      data: {
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        that.setData({
          "moviearr": res.data.ms,
          "type":0
        })

      }
    });

  },
  nowmovie:function (e) {
    var that = this;
    console.log("开始")
    wx.showLoading({
      title: '查找中',
    })
    wx.request({
      url: 'https://api-m.mtime.cn/Showtime/LocationMovies.api?locationId=290',
      method: "get",
      header: {
        'content-type': 'application/json'
      },
      data: {
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data)
        that.setData({
          "moviearr":res.data.ms,
          "type":0,
          "color": ["rgb(255, 255, 255)", "rgb(199, 179, 229)", "rgb(199, 179, 229)"]
        })

      }
    });
  },
  future:function(){
    var that = this;
    console.log("开始")
    wx.showLoading({
      title: '查找中',
    })
    wx.request({
      url: 'https://api-m.mtime.cn/Movie/MovieComingNew.api?locationId=290',
      method: "get",
      header: {
        'content-type': 'application/json'
      },
      data: {
      },
      success: function (res) {
        wx.hideLoading();
        console.log(res.data.moviecomings)
        that.setData({
          "moviearr": res.data.moviecomings,
          "type":1,
          "color": ["rgb(199, 179, 229)", "rgb(255, 255, 255)", "rgb(199, 179, 229)"]
        })

      }
    });
  },
  around: function () {
    var that = this;
    console.log("开始")
    wx.showLoading({
      title: '查找中',
    })
    wx.request({
      url: 'https://m.maoyan.com/cinemas.json',
      method: "get",
      header: {
        'content-type': 'application/json'
      },
      data: {
      },
      success: function (res) {
        wx.hideLoading();
        var obj=res.data.data;
        console.log(obj)


        that.setData({
         "moviearr": obj,
         "type":2,
          "color": ["rgb(199, 179, 229)", "rgb(199, 179, 229)", "rgb(255, 255, 255)"]
        })

      }
    });
  },
  lower:function(e){
    wx.showToast({
      title: '到底啦'
    })
  }
})