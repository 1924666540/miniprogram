// movieapi.js
Page({

  /**
   * 页面的初始数据
   */
  onReady: function (res) {
    this.videoContext = wx.createVideoContext('vid')
  },
  data: {

    introduction:["上映国家","类型","上映时间","时长","票房"],
    country:"",
    type:"",
    release:"",
    time:"",
    boxoffice:"",
    movieapi:[],
    comment:[],
    show:"none"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    console.log(options.movieid)
    wx.request({
      url: 'https://ticket-api-m.mtime.cn/movie/detail.api?locationId=290',
      method: "get",
      header: {
        'content-type': 'application/json'
      },
      data: {
        movieId: options.movieid
      },
      success: function (res) {
        console.log(res.data.data)
        that.setData({
          "country": res.data.data.basic.releaseArea,
          "type": res.data.data.basic.type,
          "release": res.data.data.basic.releaseDate,
          "time": res.data.data.basic.mins,
          "boxoffice": res.data.data.boxOffice,
          "movieapi": res.data.data
        })
      }
    });

    wx.request({
      url: 'https://ticket-api-m.mtime.cn/movie/hotComment.api',
      method: "get",
      header: {
        'content-type': 'application/json'
      },
      data: {
        movieId: options.movieid
      },
      success: function (res) {
        console.log(res.data.data)
        that.setData({
          "comment":res.data.data.mini
        })
      }
    });


  },
  showvideo:function(){
    this.setData({
      "show": "block"
    })
  },
  close: function () {
    this.setData({
      "show": "none"
    });
    this.videoContext.pause()
  }
})