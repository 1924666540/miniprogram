// addrmovie.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      addrmovie:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.request({
      url: 'https://m.maoyan.com/showtime/wrap.json',
      method: "get",
      header: {
        'content-type': 'application/json'
      },
      data: {
        cinemaid: options.cinemaid
      },
      success: function (res) {
          that.setData({
            "addrmovie":res.data.data
          })
          console.log(res.data.data)
      }
    });
  }
})