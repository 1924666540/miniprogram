// type.js


var movie=[];

var pernum=6; 

var perheight=170;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    showmovie:[1,2,3,4,5,6],
    first:1,
    second:2,
    three:3,
    third:"...",
    lastNumber:6,
    total:[],
    height:510,
    moviename:"",
    years: ["全部","爱情","喜剧","动作","剧情","科幻","动画","恐怖","记录"],

    months: ["全部","大陆","美国","韩国","日本","意大利","英国","印度","其他"],
 
    days: ["全部","2017","2016","2015","2014","2013","2012","2011","更早"],
 
    value: [1, 1, 1],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.request({
      url: 'https://clownm.herokuapp.com/',
      method: "post",
      data: {
      },
      success: function (res) {
        var newarr=[];
        for (var i = 0; i < Math.ceil(res.data.movie.length / pernum) ;i++){
            newarr.push(i);
        }
        that.setData({
          "showmovie":res.data.movie.slice(0,pernum),
          "lastNumber": Math.ceil(res.data.movie.length / pernum),
         "total":newarr
        })
        movie=res.data.movie;
       // that.data.total.length=that.data.lastNumber;
        //console.log(that.data.total.length)
      }
    });
  },

//分页

  clickButton:function(e){
    var num = e.target.dataset.target;
    var jian = this.data.lastNumber - this.data.second;
    var jian2 = this.data.lastNumber - this.data.first;
    if(num=="..."){
      

      num = this.data.second + 1;
      this.setData({
        "first": this.data.first + 1,
        "second": this.data.second + 1,
        "showmovie": movie.slice((num - 1) * pernum, num * pernum),
        "height": Math.ceil((movie.slice((num - 1) * pernum, num * pernum).length) / 2) * perheight
      })

      if (jian>3){
        this.setData({
          "third": "..."
        })
      }else{
        this.setData({
          "third": this.data.second + 1
        })
      }
    }else{

      if((jian2>2)&&(this.data.first!=1)&&(Number(num)<(this.data.lastNumber-2))){
        this.setData({
          "first": this.data.first - 1,
          "second": this.data.second - 1,
          "third":"...",
          "showmovie": movie.slice((num - 1) * pernum, num * pernum),
          "height": Math.ceil((movie.slice((num - 1) * pernum, num * pernum).length) / 2) * perheight
        })
      }else{
         this.setData({
          "showmovie": movie.slice((num - 1) * pernum, num * pernum),
          "height": Math.ceil((movie.slice((num - 1) * pernum, num * pernum).length) / 2) * perheight
        })
      }

      
    }
  },

  movieinput:function(e){
    this.setData({
      moviename: e.detail.value
    })
  },
  searchmovie:function(){
    var that3=this;
    if (this.data.moviename.trim()==""){
      wx.showToast({
        title: '请输入电影名字'
      })
      return false;
    }

    wx.showLoading({
      title: '查找中',
    })

    wx.request({
      url: 'https://clownm.herokuapp.com/movies',
      method: "post",
      data: {
        name:that3.data.moviename
      },
     
      success: function (res) {
        wx.hideLoading()
        if(res.data.movie.length==0){
          wx.showToast({
            title: '没有找到该影片'
          })
          return false;
        }else{
          var newarr = [];
          for (var i = 0; i < Math.ceil(res.data.movie.length / pernum); i++) {
            newarr.push(i);
          }
          if (res.data.movie.length < 6) {
            that3.setData({

              "height": Math.ceil(res.data.movie.length / 2) * perheight
            })
          } else {
            that3.setData({
              "height": Math.ceil(pernum / 2) * perheight
            })
          }
          that3.setData({
            "showmovie": res.data.movie.slice(0, pernum),
            "lastNumber": Math.ceil(res.data.movie.length / pernum),
            "total": newarr
          })
          movie = res.data.movie;
        // that.data.total.length=that.data.lastNumber;
        //console.log(that.data.total.length)

        }

    
      }
    });

  },


  bindChange: function (e) {
    const val = e.detail.value;
    var thatt=this;
    wx.showLoading({
      title: '查找中',
    })
    wx.request({
     
      url: 'https://clownm.herokuapp.com/movies',
      method: "post",
      data: {
        type: thatt.data.years[val[0]],
        country: thatt.data.months[val[1]],
        time: thatt.data.days[val[2]]
      },
      success: function (res) {
        wx.hideLoading();
        var newarr=[];
        for (var i = 0; i < Math.ceil(res.data.movie.length / pernum); i++) {
          newarr.push(i);
        }

        if(res.data.movie.length<6){
          thatt.setData({
           
            "height": Math.ceil(res.data.movie.length / 2) * perheight
          })
        }else{
          thatt.setData({
             "height": Math.ceil(pernum / 2) * perheight
          })
        }

        console.log(res.data)
        thatt.setData({
          "showmovie": res.data.movie.slice(0, pernum),
          "lastNumber": Math.ceil(res.data.movie.length / pernum),
          "total": newarr
        })
        movie = res.data.movie;
        // console.log(that.data.showmovie)
      }
    });
  }


})