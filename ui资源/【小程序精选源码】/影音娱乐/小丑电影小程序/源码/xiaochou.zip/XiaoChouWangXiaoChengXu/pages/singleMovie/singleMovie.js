// singleMovie.js



Page({
  onReady: function (res) {
    this.videoContext = wx.createVideoContext('myVideo')
  },
  data: {
 
    single:[]
  },




  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (option) {
    var that=this;
    wx.request({
      url: 'https://clownm.herokuapp.com/singleMovie',
      method: "post",
      header: {
        'content-type': 'application/json'
      },
      data: {
        number:option.number
      },
      success: function (res) {
        that.single=res.data;
        console.log(that.single.movie[0].name)
        that.setData({
          "single": res.data
        })
      }
    });
  }

})