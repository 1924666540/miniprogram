# wechat-weapp-mapdemo

微信小程序开发mapdemo，地图导航、marker标注

版本信息：
微信web开发者工具 `v0.15.152900`


## Screenshot


![](./image/screenshot1.png)

![](./image/screenshot2.png)

![](./image/navigator.jpg)

![](./image/screenshot-marker.png)

---

## License 

MIT