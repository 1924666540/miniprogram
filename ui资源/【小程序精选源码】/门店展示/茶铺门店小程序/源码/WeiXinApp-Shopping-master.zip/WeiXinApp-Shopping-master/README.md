# WeiXinApp-Shopping
商城类的微信小程序源码
![](http://7xoz39.com1.z0.glb.clouddn.com/wx01.PNG)
