const fetch = require("../../utils/fetch");

Page({

  data: {
    proList: [],
    pageSize: 20,
    pageCurr: 1
  },

  onLoad: function (options) {
    let that = this;
    
    if (options.search) {
        //  首页和分类页面 搜索功能  跳转到案例列表
        fetch("searchAll",{
            search: options.search,
            pageCurror: that.data.pageCurr,
            pageSize: that.data.pageSize
        }).then((res)=>{
            console.log(res.data.findlist, "这是首页、分类，搜索得到的结果");
            that.setData({
                proList: res.data.findlist
            })
        });
    }

    if (options.id) {
        // 页面加载 请求对应ID的数据（如：点击APP开发，传入点击的菜单id，跳转到案例列表）
        fetch("searchType",{
            id: options.id,
            pageCurror: that.data.pageCurr,
            pageSize: that.data.pageSize
        }).then((res)=>{
            console.log(res.data.findlist, "这是菜单点击得到的结果")
            that.setData({
                proList: res.data.findlist
            })
        });
    }

  },

  onReady: function () {
  
  },
  onShow: function (options) {

  },

  onHide: function () {
  
  },

  onUnload: function () {
  
  },

  onPullDownRefresh: function () {
  
  },


  onReachBottom: function () {
  
  },

  // 点击项目 跳转到案例详情
  toCaseDetail (e) {
    wx.navigateTo({
        url: `/pages/case/case?menuid=${e.currentTarget.dataset.id}`
    })
  }

})