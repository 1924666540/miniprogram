
var app = getApp();
const fetch = require("../../utils/fetch");

Page({
    data: {
        menuList: [],
        proList: [],  //项目列表
        menuId: 0,  // 左侧菜单项的id,默认为2 即APP开发
        proBoxId: null, // 右侧的项目id 和左侧菜单栏id对应
        inputValue: ""

    },
    onLoad () {
        let that = this;
        // 页面首次加载，发送请求获取左侧菜单栏，默认让第一项选中
        fetch("searchMr").then((res)=>{
            that.setData({
                menuList: res.data.menu,
                proList: res.data.relist,
                menuId: res.data.menu[0].id
            })
        })

    },

  
    onShow(options) {
        
    },
    onHide (options) {

    },

    // 左侧菜单，点击切换功能
    menuClick (e) {
        let that = this;
        // 1.1 设置menuId 让菜单改变样式
        that.setData({
            menuId: e.target.dataset.id
        });
        // 2.发送请求去请求数据
        fetch("menuClick", {
            id: that.data.menuId,
            type: 1
        }).then((res)=>{
            that.setData({
                proList: res.data.xcx
            })
        })
    },
    // 点击项目 跳转到案例详情
    toProDetail (e) {
        let id = e.currentTarget.dataset.proid;
        
        wx.navigateTo({
            url: `/pages/case/case?menuid=${id}`
        })
    },
    // 搜索功能，跳转到商品列表页面
    searchPro (e) {
        this.setData({
            inputValue: e.detail.value
        })
    },

    // 点击搜索后，清空输入框的值
    foo () {
        if (this.data.inputValue) {
            wx.navigateTo({
                url: `/pages/productList/productList?search=${this.data.inputValue}`
            })
        }
        this.setData({
            inputValue: ""
        })
    }
}) 