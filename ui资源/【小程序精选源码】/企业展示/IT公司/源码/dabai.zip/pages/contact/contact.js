const fetch  = require("../../utils/fetch");
let app = getApp();

Page({
  data: {
    picUrl: "",
    hotline: "",
    email: "",
    address: "",
    contacts: "",
    tel: "",
    longitude: "",
    latitude: "",
    markers: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    fetch("contactDetil").then((res)=>{
        that.setData({
            picUrl: res.data.contactdetil.pic_up,
            hotline: res.data.contactdetil.rexian,
            email: res.data.contactdetil.email,
            address: res.data.contactdetil.address,
            contacts: res.data.contactdetil.man,
            tel: res.data.contactdetil.phone,
            longitude: res.data.contactdetil.jd,
            latitude: res.data.contactdetil.wd,
            markers: [{
              iconPath: "/images/marker.png",
              width: 33,
              height: 40,
              latitude: res.data.contactdetil.wd,
              longitude: res.data.contactdetil.jd  
            }]
        });
        app.globalData.longitude = res.data.contactdetil.jd;
        app.globalData.latitude = res.data.contactdetil.wd;
    })
  },

  // 点击地图，跳转
  toBigMap () {
    // wx.navigateTo({
    //   url: "/pages/map/map"
    // })
    wx.openLocation({
      latitude: parseFloat(this.data.latitude),
      longitude: parseFloat(this.data.longitude) ,
      name: this.data.address
    })

  }
})