// pages/case/case.js
var app = getApp();
var WxParse = require('../../wxParse/wxParse.js');
const fetch = require("../../utils/fetch");

Page({

  data: {
    picList: [],
    title: "",
    introduce: ""
  },

  onLoad: function (options) {
    var that = this;
    // options.id 表示从首页经典案例进入
    if (options.id) {
      fetch("caseDetil",{id: options.id}).then((res)=>{
        that.setData({
          picList: res.data.picArray, 
          title: res.data.caseDetil.tittle, 
          introduce: res.data.caseDetil.introduce
        })
        var article = res.data.caseDetil.content;
        WxParse.wxParse('article', 'html', article, that);
      })
    }
    // options.menuid 表示从商品列表页面进入
    if (options.menuid) {
      fetch("xcxDetil",{menuid: options.menuid}).then((res)=>{
        that.setData({
          picList: res.data.picArray, 
          title: res.data.detil.tittle, 
          introduce: res.data.detil.introduce
        })
        var article = res.data.detil.content;
        WxParse.wxParse('article', 'html', article, that);  
      })
    }
  },

  // 电话咨询功能
  callUs (e) {
    fetch("phone").then((res)=>{
        wx.makePhoneCall({
            phoneNumber: res.data.phone
        })
    })
  },

  // 微信咨询功能
  showWx (e) {
    // 显示 一个提示框 将微信号 呈现
    fetch("weixin").then((res)=>{
        console.log(res.data.weixin);
        wx.showModal({
            title: "微信号码",
            content: res.data.weixin,
            showCancel: "true",
            success (res) {
                if (res.confirm) {
                    console.log("用户点击确定");
                }
            }
        })
    })
  },
  // 页面返回函数
  onUnload (options) {
    
  }

})