// pages/category/category.js
var app = getApp();
const fetch = require("../../utils/fetch");

Page({
  data: {
    picList: [],
    menuList: [],
    caseList: [],
    swiperCurrent: 0,
    inputValue: ""
  },

  onLoad: function (options) {
    let that = this;
    // 进入首页 发送请求获取页面
    fetch("allIndex").then((res)=>{
      that.setData({
        picList: res.data.pic, 
        menuList: res.data.menu, 
        caseList: res.data.case
      })
    })
  },

  onPullDownRefresh: function () {

  },

  onShareAppMessage: function () {

  },

  // 轮播图切换事件
  swiperChange (e) {
    this.setData({
        swiperCurrent: e.detail.current
    })
  },

  // 轮播图点击跳转到详情页面
  jumpCaseDetail (e) {
    let id = e.target.dataset.id;
    wx.navigateTo({
      url: `/pages/case/case?id=${id}`
    })
  },

  //  搜索框输入
  searchCase (e) {
    this.setData({
        inputValue: e.detail.value
    })
  },

  // 搜索跳转到商品列表
  foo () {
    if (this.data.inputValue) {
        // 跳转到商品列表页面
        wx.navigateTo({
            url: `/pages/productList/productList?search=${this.data.inputValue}`
        });
    }
    this.setData({
        inputValue: ""
    })
  },


  //  菜单点击跳转函数
  navTo (e) {
    let dataSet = e.currentTarget.dataset;
    app.globalData.menuId = dataSet.id;
    app.globalData.menuType = dataSet.type;
    // type=1 跳转到商品列表页面
    if (dataSet.type == 1) {
        wx.navigateTo({
            url: `/pages/productList/productList?id=${dataSet.id}&type=${dataSet.type}`
        })
    }
    if (dataSet.type == 2) {
        wx.navigateTo({
          url: `/pages/profile/profile?id=${dataSet.id}&type=${dataSet.type}`
        })
    }
    if (dataSet.type == 3) {
        wx.navigateTo({
            url: `/pages/member/member?id=${dataSet.id}&type=${dataSet.type}`
        })
    }
    if (dataSet.type == 4) {
        wx.navigateTo({
            url: `/pages/corporation/corporation?id=${dataSet.id}&type=${dataSet.type}`
        })
    }
  },

  //  案例点击跳转到详情
  toCaseDetail (e) {
    let id = e.target.dataset.id;
    wx.navigateTo({
      url: `/pages/case/case?id=${id}`
    })
  }
})