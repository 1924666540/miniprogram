//  发送请求的公共函数
module.exports = (url, data) => {
	return new Promise((resolve, reject) => {
		wx.request({
			url: `http://test.dckeji.cn/dcconsult/interface/${url}`,
			data: data,
			success: resolve,
			fail: reject
		});
	})
}
