# wechat_kacar
微信小程序demo之模仿某汽车app，只是简单的玩了一下，还有许多值得研究的地方。有时间再更新…… 

新闻页 <br/>
 ![Foo](https://github.com/dnzhu/wechat_kacar/blob/master/imgs/news.png)
