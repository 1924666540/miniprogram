// pages/my/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    screenWidth: 600,
    currentSelect: 1,
    items: [{
      'title': '一年期综合意外保险',
      'status': '保障中',
      'person': '黄荣品',
      'type':'本人',
      'date': '2013.03.03-2013.02.02'

    },
    {
      'title': '一年期综合意外保险',
      'status': '保障中',
      'person': '黄荣品',
      'type': '本人',
      'date': '2013.03.03-2013.02.02'

    },
    {
      'title': '一年期综合意外保险',
      'status': '保障中',
      'person': '黄荣品',
      'type': '本人',
      'date': '2013.03.03-2013.02.02'
    }

    ]
  },
  MyLogin: function (code, name, avatar) {
    //创建一个dialog

    var API_URL = "http://wuxiyundongweilai/api/auth/user/wechat";
    wx.showToast({
      title: '正在登录...',
      icon: 'loading',
      duration: 10000
    });
    //请求服务器
    wx.request({
      url: API_URL,
      data: {
        name: name,
        wechatcode: code,
      },
      method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {
        'content-type': 'application/json'
      }, // 设置请求的 header
      success: function (res) {
        //清空本地缓存
        var appInstance = getApp();
        wx.setStorageSync('code', code);//持续化存储code
        wx.setStorageSync('user_id', res.data.data.id);
        wx.setStorageSync('token', res.data.data.token);
        if (res.data.data.avatar != "") {
          wx.setStorageSync('avatar', res.data.data.avatar);
        }
        else {
          wx.setStorageSync('avatar', avatar);
        }
        appInstance.globalData.token = res.data.data.token;
        wx.hideToast();
      },
      fail: function () {
        // fail
        wx.hideToast();
      },
      complete: function () {
        // complete
      }
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        console.log(res.windowWidth)
        that.setData({
          screenWidth: res.windowWidth * 0.9,
        })
      },
    })


    wx.login({//login流程
      success: function (res) {//登录成功
        if (res.code) {
          var code = res.code;


          wx.getUserInfo({//getUserInfo流程
            success: function (res2) {//获取userinfo成功
              wx.clearStorage()
              that.MyLogin(code, res2.userInfo.nickName, res2.userInfo.avatarUrl);
              console.log('服务器返回' + code);
              var appInstance = getApp();
              appInstance.globalData.userInfo = res2.userInfo;
              appInstance.globalData.userName = res2.userInfo.nickName;
              wx.setStorageSync('username', res2.userInfo.nickName);
              //wx.setStorageSync('avatar', res2.userInfo.avatarUrl );
            }
            ,
            fail: function (res) {
              console.log('服务器返回' + res);


              wx.openSetting({
                success: function (data) {
                  if (data) {
                    if (data.authSetting["scope.userInfo"] == true) {
                      //允许授权
                    }
                  }
                },
                fail: function () {
                  console.info("设置失败返回数据");
                }
              })
            }

          })

        } else {
          console.log('获取用户登录态失败！' + res.errMsg)
        }

      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})