// pages/home/index.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    screenWidth:600,
    tabs:[{
           id:1,
           title:'全部',
           icon: 'social-buffer',
           },{
             id: 2,
             title:'健康险',
             icon:'medkit',
           },{
             id: 3,
             title:'意外险',
             icon:'heart-broken',
           },{
             id: 4,
             title:'旅行险',
             icon:'model-s',
           },{
             id: 5,
             title:'家财险',
             icon:'home',
           }],
    currentSelect:1,
    items: [{
      'image': "https://www.f-c.wang/storage/app/image/pingan/item1_01.png",
      'title': '一年期综合意外保险-24小时 360度保障',
      'subTitle': '最高600万|不限医保|续至80岁',
      'price':'228元起',
      'type':'3'

    },
    {
      'image': "https://www.f-c.wang/storage/app/image/pingan/show_01.png",
      'title': '百万任我行2017-出行保障期满期返百分之110',
      'subTitle': '最高600万|不限医保|续至80岁',
      'price': '228元起',
      'type': '4'

    },
    {
      'image': "https://www.f-c.wang/storage/app/image/pingan/show_02.png",
      'title': 'e生保（2017版）-最高保额600万，癌症保额翻倍',
      'subTitle': '最高600万|不限医保|续至80岁',
      'price': '228元起',
      'type': '2'
    }

    ]
  },
  onLoad: function () {
    var that =this;
    wx.getSystemInfo({
      success: function(res) {
        console.log(res.windowWidth)
        that.setData({
          screenWidth:res.windowWidth*0.9,
        })
      },
    })
  },
  onTab:function(e)
  {
    //点击
    var index = e.currentTarget.dataset.id;
   // console.log(e.currentTarget.dataset.id)
    this.setData({
      currentSelect:index,
    })

  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})