# ArticleList-weixin-xiaochengxu-server
微信小程序 托福资料(已上线) 服务器端源码

## 服务器
### 采用的是springmvc+mybatis架构
### 主要包含，后台cms管理系统和微信小程序接口

## 客户端
地址：https://github.com/AppleHuang/ArticleList-weixin-xiaochengxu-client
