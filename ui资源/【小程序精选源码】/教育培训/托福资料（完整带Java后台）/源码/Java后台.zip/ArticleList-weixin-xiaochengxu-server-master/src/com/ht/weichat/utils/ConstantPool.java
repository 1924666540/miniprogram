package com.ht.weichat.utils;

/**
 * Created by huangtao on 17/1/8.
 */
public class ConstantPool {
//    public static final String IP = "http://118.89.227.195:8080";
    public static final String IP = "http://118.89.227.195:8080";


    public static final Integer PAGESIZE = 5;
}
