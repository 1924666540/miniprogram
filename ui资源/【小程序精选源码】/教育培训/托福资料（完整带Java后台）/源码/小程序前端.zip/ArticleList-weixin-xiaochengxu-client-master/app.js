//app.js
App({
  ROOT_URL: 'https://www.yodedu.com',
  onLaunch: function () {
  },
  getUserInfo:function(cb){
  },
  globalData:{
  }
})