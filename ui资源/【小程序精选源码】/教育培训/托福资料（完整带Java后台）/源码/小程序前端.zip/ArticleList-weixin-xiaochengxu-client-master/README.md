# ArticleList-weixin-xiaochengxu-client
微信小程序 托福资料(已上线) 客户端源码

服务器采用java编写，使用的是springmvc+mybatis架构   地址：https://github.com/AppleHuang/ArticleList-weixin-xiaochengxu-server
