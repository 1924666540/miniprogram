# Weapp-jandan

微信小程序--煎蛋

![http://www.arkilis.me/wp-content/uploads/2017/03/icon.png](http://www.arkilis.me/wp-content/uploads/2017/03/icon.png)

## 1. 效果图 (Final Screenshot)

![http://www.arkilis.me/wp-content/uploads/2017/03/jandan.gif](http://www.arkilis.me/wp-content/uploads/2017/03/jandan.gif)



## 功能：

* 无聊图
* 段子
* <font color='red'>妹子图</font> （这个是必须的）
* 投票


__Github 地址__: [https://github.com/arkilis/weapp-jandan](https://github.com/arkilis/weapp-jandan)

----

## 2. 声明 (Disclaim)

 <font color='red' style="font-size:20px"><strong>真机调试不可用，因为，煎蛋的服务器没有正确地配置SSL证书，见谅~~~~</strong></font>

如果有朋友告知怎么绕过这个证书错误，请告知多谢，🤗


![http://www.arkilis.me/wp-content/uploads/2017/03/jandan1.png](http://www.arkilis.me/wp-content/uploads/2017/03/jandan1.png)

![http://www.arkilis.me/wp-content/uploads/2017/03/jandan2.png](http://www.arkilis.me/wp-content/uploads/2017/03/jandan2.png)


----



## 3. 作者 Contact

__Weclome to my blog:__ [http://arkilis.me](http://arkilis.me)

__Twitter:__ [https://twitter.com/arkilis](https://twitter.com/arkilis)

__Wechat:__ ![http://www.arkilis.me/wp-content/uploads/2017/03/mywechat_144_144.png](http://www.arkilis.me/wp-content/uploads/2017/03/mywechat_144_144.png)
