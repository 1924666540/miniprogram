//bookList.js 个人中心共用图书列表
//获取应用实例
var app = getApp()
Page({
    data: {
        userInfo: {},
    },
   
    onLoad: function () {

    },

})
