const sinabookUrl = "https://221.179.190.191/prog/weixin/weixin-sinaread-api/";  
module.exports = {getBookList: sinabookUrl + "list_api.php", getBookDetail: sinabookUrl + "detail_api.php?id=",getBookById: sinabookUrl + "detail_api.php?id="}
