<?php
/**
 * Created by PhpStorm.
 * User: vread
 * Date: 2016/11/29
 * Time: 11:20
 */
$data = array(
    "112901" => array(
        "img"   =>"http://vipbook.sinaedge.com/bookcover/tiny85/54/cover_03f20f2b2f8d7c7df7338c706034ebbf.jpg",
        'id'      =>"112901",
        "author" =>"风雪云中路",
        'title'       =>"抗日之我为战神",
        'publisher'     =>"新华出版社",
        'pubdate'         =>"2003-05-01",
        'info'       =>"第一次见苏墨的时候，我直接把他当成是服务业；结账前，他笑着说道",
        'tags'            =>"科幻",
    ),
    "112902" => array(
        "img"   =>"http://vipbook.sinaedge.com/bookcover/tiny85/68/cover_9890d08e8d66f9684ca0ab28872c6862.jpg",
        'id'      =>"112902",
        "author" =>"红烧龙虾",
        'title'       =>"我的绝色明星老婆",
        'publisher'     =>"新华出版社",
        'pubdate'         =>"2003-05-01",
        'info'       =>"第一次见苏墨的时候，我直接把他当成是服务业；结账前，他笑着说道",
        'tags'            =>"科幻",
    ),
    "112903" => array(
        "img"   =>"http://vipbook.sinaedge.com/bookcover/tiny85/18/cover_2f1dd6751a700aac91996880094bea35.jpg",
        'id'      =>"112903",
        "author" =>"虾米XL",
        'title'       =>"吞噬苍穹",
        'publisher'     =>"新华出版社",
        'pubdate'         =>"2003-05-01",
        'info'       =>"第一次见苏墨的时候，我直接把他当成是服务业；结账前，他笑着说道",
        'tags'            =>"科幻",
    ),
    "112904" => array(
        "img"   =>"http://vipbook.sinaedge.com/bookcover/tiny85/226/cover_17640aa3b53062c38a88224e0e7eca68.jpg",
        'id'      =>"112904",
        "author" =>"暗丶修兰",
        'title'       =>"阴阳代理人之改命师",
        'publisher'     =>"新华出版社",
        'pubdate'         =>"2003-05-01",
        'info'       =>"七岁，我以为我会和普通的孩子一样长大，工作，成家，但是因为误碰",
        'tags'            =>"科幻",
    ),
);
