<?php

$booklist = array("title"=>"书名123");
$arr = array('count'=>1,'error_code'=>0,'data'=>$booklist);

echo json_encode($arr);
