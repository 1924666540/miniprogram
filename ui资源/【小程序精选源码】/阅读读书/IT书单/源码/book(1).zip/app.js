//app.js
App({
  onLaunch: function () {
  }
})