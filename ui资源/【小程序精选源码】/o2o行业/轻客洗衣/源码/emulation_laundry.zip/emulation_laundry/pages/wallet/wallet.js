// pages/wallet/wallet.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      // 充值数额类型数组
    checkboxValue: [],
    // 提交按钮的背景色，未勾选类型时无颜色
    btnBgc: "",
    // 复选框的value，此处预定义，然后循环渲染到页面
    itemsValue: [
      {
        checked: false,
        value: "充值¥10轻币",
        color: "#b9dd08"
      },
      {
        checked: false,
        value: "充值¥20轻币",
        color: "#b9dd08"
      },
      {
        checked: false,
        value: "充值¥50轻币",
        color: "#b9dd08"
      },
      {
        checked: false,
        value: "充值¥60轻币",
        color: "#b9dd08"
      },
      {
        checked: false,
        value: "充值¥80轻币",
        color: "#b9dd08"
      },
      {
        checked: false,
        value: "充值¥100轻币",
        color: "#b9dd08"
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  // 页面加载
  onLoad:function(options){
    wx.setNavigationBarTitle({
      title: '我的钱包'
    })
  },
// 勾选充值金额，获取类型值存入checkboxValue
  checkboxChange: function(e){
    let _values = e.detail.value;
    if(_values.length == 0){
      this.setData({
        btnBgc: ""
      })
    }else{
      this.setData({
        checkboxValue: _values,
        btnBgc: "#b9dd08"
      })
    }   
  },
// 输入充值金额，存入inputValue
  numberChange: function(e){
    this.setData({
      inputValue: {
        num: e.detail.value,
        desc: this.data.inputValue.desc
      }
    })
  },
// 输入备注，存入inputValue
  descChange: function(e){
    this.setData({
      inputValue: {
        num: this.data.inputValue.num,
        desc: e.detail.value
      }
    })
  },
// 提交到服务器
  formSubmit: function(e){
    if(this.data.checkboxValue.length> 0){
      wx.request({
        url: 'https://www.easy-mock.com/mock/59098d007a878d73716e966f/ofodata/msg',
        data: {
        },
        method: 'get', 
        success: function(res){
          wx.showToast({
            title: res.data.data.msg,
            icon: 'success',
            duration: 2000
          })
        }
      })
    }else{
      wx.showModal({
        title: "请填写反馈信息",
        content: '你宝贵的意见是我们改进的方向',
        confirmText: "如实填写",
        cancelText: "忽略",
        success: (res) => {
          if(res.confirm){
            // 继续填
          }else{
            console.log("back")
            wx.navigateBack({
              delta: 1 // 回退前 delta(默认为1) 页面
            })
          }
        }
      })
    }   
  }
})