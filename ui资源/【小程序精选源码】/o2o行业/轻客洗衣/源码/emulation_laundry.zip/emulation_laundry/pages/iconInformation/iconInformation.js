// pages/iconInformation/iconInformation.js
var app = getApp()
Page({
    data: {
        translate: '',
        showPageBottom: false
    },

    
    showMenu: function() {
        this.setData({
            showPageBottom: !this.data.showPageBottom
        })
    },
    
    myWallet: function() {
      wx.navigateTo({
        url: '../wallet/wallet'
      })
    },
    myCoupons: function() {
      wx.navigateTo({
        url: '../coupons/coupons'
      })
    },
    myWashing: function() {
      wx.navigateTo({
        url: '../machine/machine'
      })
    },
    mySetting: function() {
      wx.navigateTo({
        url: '../setting/setting'
      })
    },

    icon_Sms: function() {
      wx.navigateTo({
        url: '../sms/sms'
      })
    },
    icon_Click:function() {
      wx.navigateTo({
        url: '../iconClick/iconClick'
      })
    },

    icon_User:function() {
      wx.navigateTo({
        url: '../user/user'
      })
    },
    
    icon_toFriend:function() {
      wx.navigateTo({
        url: '../toFriend/toFriend'
      })
    },
    icon_option:function () {
        wx.navigateTo({
        url: '../myoption/myoption'
      })
    }
})